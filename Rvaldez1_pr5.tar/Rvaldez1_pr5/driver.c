#include <unistd.h> 
#include <stdio.h> 
#include <string.h> 
#include <stdlib.h> 
#include "pr5.h"

//Raymond Valdez
//pr5
//Code is tested on the cssgate server

void method1(FILE * );
void method2(FILE * );
void method3(FILE * );
void method4(FILE * );
void method5(FILE * );
void writeFile(FILE * );

// in this main method, the file 'animals.dat' is opened and will be read and also rewritten.
// the while-loop inside will prompt the user to select integer values from 0 through 5.
// if the user selects 1, method 1 will run.
// if the user selects 2, method 2 wll run.
// if the user selects 3, method 3 will run.
// if the user selects 4, method 4 will run.
// if the user selects 5, method 5 will run.
// if the user does not select an integer value from 0 through 5, the code will continuously prompt the user to enter 0 - 5 until they comply.
// if the user enters '0', the writeFile() method will run and will write a new "summary.csv" file with the new updated animals.
// each method has an fseek() function acting like a ptr rewind to make sure that the pointer is always pointing to the top of the file.

int main() {
  FILE * ptrBin = fopen("animals.dat", "rb+");

  if (ptrBin == NULL) {
    printf("Binary file does not exist");
  }
  int input = 6;

  while (input != 0) {
    printf("Please make a selection from '1' through '5', enter '0' to quit \n");
    input = 6;
    scanf("%d", & input);
    while (getchar() != '\n') {}
    if (input == 1)
      method1(ptrBin);
    else if (input == 2)
      method2(ptrBin);
    else if (input == 3)
      method3(ptrBin);
    else if (input == 4)
      method4(ptrBin);
    else if (input == 5)
      method5(ptrBin);
  }

  printf("Writing updated animals into animals.csv\n");
  writeFile(ptrBin);
  printf("END");

  return 0;
}

//method 1 reads the file byte by byte and will only print ASCII values from 32-127.
//the program will return to the main menu once this menu is finished executing.
void method1(FILE * ptr) {
  char ch;
  int i;
  int count = 0;
  printf("You are in method 1\n");
  fseek(ptr, 0, SEEK_SET);

  while (!feof(ptr)) {
    fread( & ch, sizeof(char), 1, ptr);
    printf("%c", ch);
    count++;
    if (count % 80 == 0) {
      printf("\n");
    }
  }
  printf("\n");
}

//method 2 almost follows the same logic as method 1, except method 2 reads 4 bytes at a time.
//the will print onto the console the corresponding integer value of the bytes.
void method2(FILE * ptr) {
  int i;
  int count = 0;
  fseek(ptr, 0, SEEK_SET);

  printf("You are in method 2\n");

  while (!feof(ptr)) {
    fread( & i, sizeof(int), 1, ptr);
    printf("%d ", i);
    count++;
    if (count % 7 == 0) {
      printf("\n");
    }
  }
}

//method 3 displays the animal that you would like to display corresponding to the id that the user enters.
//for example, if the user enters '3', animal with id '3' will display on the screen.
void method3(FILE * ptr) {
    //This fseek() will make sure that the pointer is resetted to the beginning of the file.
    fseek(ptr, 0, SEEK_SET);
    int i;
    int User = -1;
    // we allocate memory of size "animal" to a pointer of type animal. This pointer will utilize the animal method "printAnimal()" to display it on the screen.
    struct animal * A = malloc(sizeof(struct animal));
    int count = 0;

    //This while-loop reads how many animals there are in the file.
    //The while-loop counts the amount of animals there are in the file with a counter variable "count".
    while (!feof(ptr)) {
      fread(A, sizeof(struct animal), 1, ptr);
      count++;
    }
    count--; //this piece of code makes sure that there is the correct amount of animals on the file.

    //resets the file to the beginning
    fseek(ptr, 0, SEEK_SET);
    //displays on the screen how many animals there are
    printf("There are %d animals in the file \n", count);
    //"if" condition for if there are no animals
    if (count == 0) {
      printf("There are no animals to print");
    }

    //"if" condition if there is only one animal,
    if (count == 1) {
      printAnimal(A);
    }

    //"else if condition if there are no records to display."
    else if (count == 0) {
      printf("There are no records to display");
    }

    //else condition for when there isn't just 1 animal.
    //the user will need to input a value in between 0 and "count". 
    //if the user does not enter an appropriate value, then the code will return to the main menu.
    //if the user does enter an appropriate integer, then the animal with an id corresponding to the users input will print onto the screen.
    else {
      if (User > count || User <= 0) {
        printf("Please select an animal id from 1 to %d that you would like to display on the screen\n", count);
        scanf("%d", & User);
      }
      for (i = 1; i <= User; i++) {
        fread(A, sizeof(struct animal), 1, ptr);
      }
      if (User <= count && User >= 1) {
        printAnimal(A);
      } else
        printf("error: You did not input a valid integer\nreturning to Main menu. \n");

    }
  } //end of method 3

//method 4 lets the user select an animal that they wish to update, then lets the user choose which of the 4 fields they would like to update.
//if user selects 1, they will update the name.
//if user selects 2, they will update the species.
//if user selects 3, they will update the size.
//if user selects 4, they will update the age.
void method4(FILE * ptr) {
  fseek(ptr, 0, SEEK_SET);
  //we allocate memory to 'A' so that it can hold the animal that we wish to update, update the animal, then place the animal back into the binary file.
  struct animal * A = (struct animal * ) malloc(sizeof(struct animal));
  int onOff = 0;
  int i, count, choiceA, choiceUpdate;

  //Just like method 3, we use the same logic to count how many animals there are in the file
  while (!feof(ptr)) {
    fread(A, sizeof(struct animal), 1, ptr);
    count++;
  }
  count--;
  fseek(ptr, 0, SEEK_SET);
  printf("There are %d animals in the file \n", count);

  //this "if" condition prompts the user to select an integer value from 1 through count;
  //if the user does not select an appropriate animal to update, the code will return to the main menu.
  //if the user does select an appropriate value, the animal will display on the screen.
  //the user is then prompted to enter an integer value between 1 through 4. corresponding to the field they would like to update.
  if (choiceA > count || choiceA <= 0) {
    printf("Please select an animal id from 1 to %d that you would like to update\n", count);
    scanf("%d", & choiceA);
  }
  for (i = 1; i <= choiceA; i++) {
    fread(A, sizeof(struct animal), 1, ptr);
  }
  if (choiceA <= count && choiceA >= 1) {
    printf("This is the animal that you want to update\n");
    printAnimal(A);
    printf("\n\n");
  } else {
    printf("error: You did not input a valid integer returning to main menu\n");
    onOff = 1; //this onOff decides if the next lines of code will run
  }

  //this 'if' statement only runs if the user selects an appropriate animal to update.
  if (onOff == 0) {
    printf("Which field would you like to update?\nEnter 1 for Name\nEnter 2 for species\nEnter 3 for size\nEnter 4 for age");
    scanf("%d", & choiceUpdate);
    if (choiceUpdate < 1 || choiceUpdate > 4) {
      printf("error: you did not select a valid choice, returning to main menu\n");
    } else {
      //if the user selects 1, we prompt the user to update the name of the animal.
      if (choiceUpdate == 1) {
        printf("you selected 1, enter the new name\n");
        updateAnimalName(A);
        fseek(ptr, 0, SEEK_SET);
        fseek(ptr, sizeof(struct animal) * (choiceA - 1), SEEK_SET);
        fwrite(A, sizeof(struct animal), 1, ptr);

        fseek(ptr, 0, SEEK_SET);

      }
      //if the user selects 2, we prompt the user to update the species of the animal.
      if (choiceUpdate == 2) {
        printf("you selected 2, enter new species\n");
        updateAnimalSpecies(A);
        fseek(ptr, 0, SEEK_SET);
        fseek(ptr, sizeof(struct animal) * (choiceA - 1), SEEK_SET);
        fwrite(A, sizeof(struct animal), 1, ptr);
        fseek(ptr, 0, SEEK_SET);
      }
      //if the user selects 3, we prompt the user to update the size of the animal.
      if (choiceUpdate == 3) {
        printf("you selected 3, enter new size\n");
        updateAnimalSize(A);
        fseek(ptr, 0, SEEK_SET);
        fseek(ptr, sizeof(struct animal) * (choiceA - 1), SEEK_SET);
        fwrite(A, sizeof(struct animal), 1, ptr);

        fseek(ptr, 0, SEEK_SET);
      }
      //if the user selects 4, we prompt the user to update the age of the animal.
      if (choiceUpdate == 4) {
        printf("you selected 4, update new age\n");
        updateAnimalAge(A);
        fseek(ptr, 0, SEEK_SET);
        fseek(ptr, sizeof(struct animal) * (choiceA - 1), SEEK_SET);
        fwrite(A, sizeof(struct animal), 1, ptr);

        fseek(ptr, 0, SEEK_SET);
      }
    }
  }
  onOff = 0;
  free(A); //we will free the pointer pointing to the animal
}

//method 5 checks the number of animals there are in the file.
//the user is prompted to enter an appropriate animal id from 0 to count.
//that animal id is then removed from the binary file and the file is then truncated.
void method5(FILE * ptr) {
    fseek(ptr, 0, SEEK_SET);
    struct animal * A = (struct animal * ) malloc(sizeof(struct animal));
    struct animal * B = (struct animal * ) malloc(sizeof(struct animal));
    int id, choiceA, i;
    int count = 0;
    int onOff = 0;
    char String[30];

    //counts the number of animals in the file using the same logic as the above methods.
    while (!feof(ptr)) {
      fread(A, sizeof(struct animal), 1, ptr);
      count++;
    }
    count--;
    fseek(ptr, 0, SEEK_SET);
    printf("There are %d animals in the file \n", count);

    //checks if the choice is valid
    if (choiceA > count || choiceA <= 0) {
      printf("Please select an animal id from 1 to %d that you would like to clear\n", count);
      scanf("%d", & choiceA);
    }
    for (i = 1; i <= choiceA; i++) {
      fread(A, sizeof(struct animal), 1, ptr);
    }
    if (choiceA <= count && choiceA >= 1) {
      printf("This animal is removed from the records\n");
      printAnimal(A);
      printf("\n\n");
    } else {
      printf("error: You did not input a valid integer returning to main menu\n");
      onOff = 1; //this onOff decides if the next lines of code will run
    }

    //this line makes sure that we return to the main menu if an invalid choice above has been made.
    if (onOff != 1) {
      //if condition for when the last animal is the one we want to get rid of
      if (choiceA == count) {
        fseek(ptr, 0, SEEK_END);
        ftruncate(fileno(ptr), sizeof(struct animal) * (count - 1));
      }

      //else statement if the record to delete is in the beginninng of the file.        
      else {
        //here is where we delete the actual file by moving the pointer forward and overwriting the file before it.
        for (i = 0; i < (count - choiceA); i++) {
          fread(B, sizeof(struct animal), 1, ptr);
          fseek(ptr, -(2 * sizeof(struct animal)), SEEK_CUR);
          fwrite(B, sizeof(struct animal), 1, ptr);
          fread(B, sizeof(struct animal), 1, ptr);
        }

        //we are now fixing the ID of the animals after we removed it
        for (i = choiceA; i < count; i++) {
          fseek(ptr, sizeof(struct animal) * (i - 1), SEEK_SET);
          fread(A, sizeof(struct animal), 1, ptr);
          updateAnimalID(A, i);
          fseek(ptr, sizeof(struct animal) * (i - 1), SEEK_SET);
          fwrite(A, sizeof(struct animal), 1, ptr);
        }

        //shrink the file
        ftruncate(fileno(ptr), sizeof(struct animal) * (count - 1));
      } //end of else statement
    }

    //we free the pointers holding animal data
    free(A);
    free(B);
  }
  //this file will write the updated animals into animals.csv and skip animals with an unknown name.
  //we do this by writing in the animals one by one into the file
void writeFile(FILE * ptr) {
  char * unknown = "unknown";
  char * Aname = malloc(sizeof(char) * 20);

  FILE * ptrSum = fopen("animals.csv", "wb");
  int count = 0;
  struct animal * A = (struct animal * ) malloc(sizeof(struct animal));
  fseek(ptrSum, 0, SEEK_SET);
  fseek(ptr, 0, SEEK_SET);
  int i;
  int idcount = 1;

  while (!feof(ptr)) {
    fread(A, sizeof(struct animal), 1, ptr);
    count++;
  }
  count--;
  fseek(ptr, 0, SEEK_SET);

  for (i = 0; i < count; i++) {
    fread(A, sizeof(struct animal), 1, ptr);
    Aname = A->name;
    if (strcmp(Aname, unknown) != 0) {
      fprintf(ptrSum, "%d,%s,%s,%c,%d\n", idcount, A->name, A->species, A->size, A->age);
      idcount++;
    }
  }
}