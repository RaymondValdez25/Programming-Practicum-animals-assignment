#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#pragma pack(1)

struct animal {
  short int id;
  char name[20];
  char species [35];
  char size;
  short int age;
};


 void printAnimal(struct animal *);
 void updateAnimalName(struct animal *);
 void updateAnimalSpecies(struct animal *);
 void updateAnimalSize(struct animal *);
 void updateAnimalAge(struct animal *);
 void updateAnimalID(struct animal *,int);