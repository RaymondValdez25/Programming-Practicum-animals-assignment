#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "pr5.h"
#pragma pack(1)


/*
struct animal {
  short int id;
  char name[20];
  char species [35];
  char size;
  short int age;
};
*/


  void printAnimal(struct animal * A){
  printf("ID: %d\n", A->id);
  printf("name: %s\n", A->name);
  printf("species: %s\n",A->species);
  printf("size: %c\n", A->size);
  printf("age: %d\n", A->age);
  }


  void updateAnimalName(struct animal * A){
  char String[20];
  getchar();
  scanf("%[^\n]", &String);
  getchar();
  strcpy(A->name, String);
  }

  void updateAnimalSpecies(struct animal * A){
  char String[20];
  getchar();
  scanf("%[^\n]", &String);
  getchar();
  strcpy(A->species, String);
  }


  void updateAnimalSize(struct animal * A){
  char Size;
  scanf("%c", &Size);
  A->size = Size;
  }

  void updateAnimalAge(struct animal * A){
  int a;
  scanf("%d", &a);
  A->age = a;
  } 



  void updateAnimalID(struct animal * A, int i){
  A->id = i;
  }

  

  